package com.aaa.mvc.dao;

import java.util.List;
import java.util.Map;

public interface AdminDao {
	/**
	 * 后台登陆账户密码查询
	 * @return
	 */
	List<Map<String,Object>> adminLogin();
}
