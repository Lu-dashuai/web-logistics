package com.aaa.mvc.dao;

import java.util.List;
import java.util.Map;

public interface DistributeDao {
	public List<Map<String, Object>> getPage(int start, int rows, Map map);
	public  List<Map<String, Object>> getPageCount(Map map);
	public int updateStatus(Map map);
	public Object selectPeople();
	public List<Map<String, Object>> getById(String id);
}
